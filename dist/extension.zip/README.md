# FastAudioWhatsapp
Change the speed of audios in whatsapp web

![screenshot](img/screenshot.png)

---
![](img/icons/icon_x60.png) | Firefox | Chrome
---|---|---
URL | [addon](https://addons.mozilla.org/pt-BR/firefox/addon/fastaudiowhatsapp/) | _unavailable_

## Build after edit:
> use zip

create zip file on linux or mac:
`$ zip dist/extension.zip * **/**`


